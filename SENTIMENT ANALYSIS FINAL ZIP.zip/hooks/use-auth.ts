'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { AuthState } from '@/lib/types'

const VALID_REGISTRATION = '24BCS7013'

export function useAuth() {
  const [auth, setAuth] = useState<AuthState>({
    isAuthenticated: false,
    registrationNumber: null,
  })
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const storedAuth = localStorage.getItem('sentilytics-auth')
    if (storedAuth) {
      const parsed = JSON.parse(storedAuth)
      setAuth(parsed)
    }
    setLoading(false)
  }, [])

  const login = (registrationNumber: string) => {
    if (registrationNumber === VALID_REGISTRATION) {
      const newAuth = {
        isAuthenticated: true,
        registrationNumber,
      }
      setAuth(newAuth)
      localStorage.setItem('sentilytics-auth', JSON.stringify(newAuth))
      router.push('/dashboard')
      return true
    }
    return false
  }

  const logout = () => {
    setAuth({
      isAuthenticated: false,
      registrationNumber: null,
    })
    localStorage.removeItem('sentilytics-auth')
    router.push('/auth')
  }

  const requireAuth = (callback: () => void) => {
    if (!auth.isAuthenticated && !loading) {
      router.push('/auth')
      return
    }
    callback()
  }

  return {
    auth,
    loading,
    login,
    logout,
    requireAuth,
    isAuthenticated: auth.isAuthenticated,
  }
}
