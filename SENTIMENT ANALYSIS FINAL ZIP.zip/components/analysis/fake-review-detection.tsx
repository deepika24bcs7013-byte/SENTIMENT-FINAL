'use client'

import { Card } from '@/components/ui/card'
import { SentimentAnalysis } from '@/lib/types'
import { AlertCircle, Star } from 'lucide-react'

interface FakeReviewDetectionProps {
  analysis: SentimentAnalysis
}

export function FakeReviewDetection({ analysis }: FakeReviewDetectionProps) {
  const riskLevel = analysis.fakeReviewPercentage > 15 ? 'high' : analysis.fakeReviewPercentage > 5 ? 'medium' : 'low'

  return (
    <div className="grid grid-cols-2 gap-6">
      {/* Fake Review Detection */}
      <Card className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <AlertCircle className="h-5 w-5 text-destructive" />
              <h3 className="font-semibold text-foreground">Fake Review Risk</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Percentage of potentially fraudulent reviews detected
            </p>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-bold text-destructive">
                {analysis.fakeReviewPercentage}%
              </span>
              <span className={`text-xs px-3 py-1 rounded-full ${
                riskLevel === 'high' ? 'bg-destructive/10 text-destructive' :
                riskLevel === 'medium' ? 'bg-yellow-500/10 text-yellow-500' :
                'bg-sentiment-positive/10 text-sentiment-positive'
              }`}>
                {riskLevel.toUpperCase()} RISK
              </span>
            </div>
          </div>
          <div className="h-24 w-24 rounded-full border-4 border-destructive/20 flex items-center justify-center">
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Risk Level</p>
              <p className="text-xl font-bold text-foreground">{riskLevel}</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Rating Prediction */}
      <Card className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Star className="h-5 w-5 text-yellow-500" />
              <h3 className="font-semibold text-foreground">Predicted Rating</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Based on sentiment analysis and review data
            </p>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-bold text-primary">
                {analysis.predictedRating.toFixed(1)}
              </span>
              <span className="text-lg text-muted-foreground mb-2">/5.0</span>
            </div>
          </div>
          <div className="text-right">
            <div className="flex gap-1 justify-end mb-2">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className="h-6 w-6"
                  fill={i < Math.round(analysis.predictedRating) ? '#FFD700' : '#E5E5E5'}
                  color={i < Math.round(analysis.predictedRating) ? '#FFD700' : '#E5E5E5'}
                />
              ))}
            </div>
            <p className="text-xs text-muted-foreground">Confidence: High</p>
          </div>
        </div>
      </Card>
    </div>
  )
}
