'use client'

import { Card } from '@/components/ui/card'
import { SentimentAnalysis } from '@/lib/types'
import { TrendingUp, TrendingDown } from 'lucide-react'

interface SentimentOverviewProps {
  analysis: SentimentAnalysis
}

export function SentimentOverview({ analysis }: SentimentOverviewProps) {
  const sentiments = [
    {
      label: 'Positive',
      value: analysis.sentiment.positive,
      color: 'bg-sentiment-positive',
      textColor: 'text-sentiment-positive',
    },
    {
      label: 'Neutral',
      value: analysis.sentiment.neutral,
      color: 'bg-sentiment-neutral',
      textColor: 'text-sentiment-neutral',
    },
    {
      label: 'Negative',
      value: analysis.sentiment.negative,
      color: 'bg-sentiment-negative',
      textColor: 'text-sentiment-negative',
    },
  ]

  return (
    <div className="grid grid-cols-3 gap-4">
      {sentiments.map((sentiment) => (
        <Card key={sentiment.label} className="p-6">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <p className="text-sm text-muted-foreground mb-2">{sentiment.label}</p>
              <div className="flex items-baseline gap-2">
                <span className={`text-4xl font-bold ${sentiment.textColor}`}>
                  {sentiment.value}%
                </span>
              </div>
              <div className={`h-1 ${sentiment.color} rounded-full mt-4 w-full`}></div>
            </div>
          </div>
        </Card>
      ))}

      <Card className="p-6 col-span-3">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm text-muted-foreground mb-2">Overall Sentiment Score</p>
            <div className="flex items-end gap-2">
              <span className="text-5xl font-bold text-primary">
                {(analysis.sentiment.overallScore * 100).toFixed(0)}
              </span>
              <span className="text-lg text-muted-foreground mb-2">/100</span>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-muted-foreground mb-2">Review Count</p>
            <p className="text-3xl font-bold text-primary">{analysis.reviewCount}</p>
          </div>
        </div>
        <div className="h-2 bg-secondary rounded-full mt-4 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-sentiment-negative via-sentiment-neutral to-sentiment-positive"
            style={{ width: `${analysis.sentiment.overallScore * 100}%` }}
          ></div>
        </div>
      </Card>
    </div>
  )
}
