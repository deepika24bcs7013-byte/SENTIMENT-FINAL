'use client'

import { Card } from '@/components/ui/card'
import { SentimentAnalysis } from '@/lib/types'
import { ThumbsUp, ThumbsDown, AlertCircle, CheckCircle2 } from 'lucide-react'

interface BuyRecommendationProps {
  analysis: SentimentAnalysis
}

export function BuyRecommendation({ analysis }: BuyRecommendationProps) {
  const { sentiment, fakeReviewPercentage, predictedRating } = analysis

  // Calculate recommendation based on multiple factors
  const positiveRatio = sentiment.positive / 100
  const negativeRatio = sentiment.negative / 100
  const overallRating = predictedRating

  // Scoring algorithm
  let recommendationScore = 0
  let factors = []

  // Factor 1: Positive sentiment ratio (weight: 40%)
  if (positiveRatio >= 0.7) {
    recommendationScore += 40
    factors.push({ label: 'Strong Positive Reviews', status: 'good' })
  } else if (positiveRatio >= 0.5) {
    recommendationScore += 30
    factors.push({ label: 'Mostly Positive Reviews', status: 'good' })
  } else if (positiveRatio >= 0.3) {
    recommendationScore += 15
    factors.push({ label: 'Mixed Reviews', status: 'neutral' })
  } else {
    recommendationScore += 0
    factors.push({ label: 'Mostly Negative Reviews', status: 'bad' })
  }

  // Factor 2: Negative sentiment ratio (weight: 25%)
  if (negativeRatio < 0.15) {
    recommendationScore += 25
    factors.push({ label: 'Few Negative Reviews', status: 'good' })
  } else if (negativeRatio < 0.3) {
    recommendationScore += 15
    factors.push({ label: 'Some Negative Reviews', status: 'neutral' })
  } else {
    recommendationScore += 0
    factors.push({ label: 'Many Negative Reviews', status: 'bad' })
  }

  // Factor 3: Overall rating (weight: 20%)
  if (overallRating >= 4.0) {
    recommendationScore += 20
    factors.push({ label: 'High Product Rating', status: 'good' })
  } else if (overallRating >= 3.0) {
    recommendationScore += 10
    factors.push({ label: 'Average Product Rating', status: 'neutral' })
  } else {
    recommendationScore += 0
    factors.push({ label: 'Low Product Rating', status: 'bad' })
  }

  // Factor 4: Fake reviews (weight: 15%)
  if (fakeReviewPercentage < 10) {
    recommendationScore += 15
    factors.push({ label: 'Low Fake Review Risk', status: 'good' })
  } else if (fakeReviewPercentage < 25) {
    recommendationScore += 8
    factors.push({ label: 'Moderate Fake Review Risk', status: 'neutral' })
  } else {
    recommendationScore += 0
    factors.push({ label: 'High Fake Review Risk', status: 'bad' })
  }

  // Determine recommendation
  let recommendation = 'PASS'
  let title = 'Recommend Caution'
  let description = 'Based on the sentiment analysis, we recommend exercising caution with this product.'
  let bgColor = 'bg-yellow-50 dark:bg-yellow-950'
  let borderColor = 'border-yellow-200 dark:border-yellow-800'
  let textColor = 'text-yellow-900 dark:text-yellow-100'
  let accentColor = 'text-yellow-600 dark:text-yellow-400'
  let icon = AlertCircle

  if (recommendationScore >= 70) {
    recommendation = 'BUY'
    title = 'Highly Recommended'
    description = 'Based on positive sentiment, good ratings, and authentic reviews, this product is worth buying.'
    bgColor = 'bg-green-50 dark:bg-green-950'
    borderColor = 'border-green-200 dark:border-green-800'
    textColor = 'text-green-900 dark:text-green-100'
    accentColor = 'text-green-600 dark:text-green-400'
    icon = CheckCircle2
  } else if (recommendationScore >= 50) {
    recommendation = 'MAYBE'
    title = 'Proceed with Caution'
    description = 'Mixed reviews suggest moderate satisfaction. Consider your specific needs before purchasing.'
    bgColor = 'bg-blue-50 dark:bg-blue-950'
    borderColor = 'border-blue-200 dark:border-blue-800'
    textColor = 'text-blue-900 dark:text-blue-100'
    accentColor = 'text-blue-600 dark:text-blue-400'
    icon = AlertCircle
  } else {
    recommendation = 'SKIP'
    title = 'Not Recommended'
    description = 'Based on negative sentiment and low ratings, we recommend looking for alternative products.'
    bgColor = 'bg-red-50 dark:bg-red-950'
    borderColor = 'border-red-200 dark:border-red-800'
    textColor = 'text-red-900 dark:text-red-100'
    accentColor = 'text-red-600 dark:text-red-400'
    icon = ThumbsDown
  }

  const IconComponent = icon

  return (
    <Card className={`${bgColor} border-2 ${borderColor} p-6`}>
      <div className="flex items-start gap-4">
        <div className={`${accentColor}`}>
          <IconComponent className="h-8 w-8" />
        </div>
        <div className="flex-1">
          <div className="flex items-center justify-between mb-2">
            <h3 className={`text-2xl font-bold ${textColor}`}>{title}</h3>
            <div className={`px-4 py-2 rounded-lg font-bold ${accentColor} bg-white/50 dark:bg-black/20`}>
              {recommendation}
            </div>
          </div>
          <p className={`${textColor} mb-4`}>{description}</p>

          {/* Recommendation Score */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className={`text-sm font-semibold ${textColor}`}>Recommendation Score</span>
              <span className={`text-lg font-bold ${accentColor}`}>{recommendationScore}%</span>
            </div>
            <div className="w-full bg-white/50 dark:bg-black/20 rounded-full h-3 overflow-hidden">
              <div
                className={`h-full ${
                  recommendationScore >= 70
                    ? 'bg-green-500'
                    : recommendationScore >= 50
                      ? 'bg-blue-500'
                      : 'bg-red-500'
                } transition-all duration-500`}
                style={{ width: `${recommendationScore}%` }}
              />
            </div>
          </div>

          {/* Analysis Factors */}
          <div className="space-y-2">
            <p className={`text-sm font-semibold ${textColor}`}>Key Factors:</p>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {factors.map((factor, idx) => (
                <li key={idx} className="flex items-center gap-2">
                  <span
                    className={`inline-block w-2 h-2 rounded-full ${
                      factor.status === 'good'
                        ? 'bg-green-500'
                        : factor.status === 'bad'
                          ? 'bg-red-500'
                          : 'bg-yellow-500'
                    }`}
                  />
                  <span className={`text-sm ${textColor}`}>{factor.label}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </Card>
  )
}
