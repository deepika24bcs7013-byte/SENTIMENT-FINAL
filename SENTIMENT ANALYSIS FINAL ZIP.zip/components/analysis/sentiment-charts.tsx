'use client'

import { Card } from '@/components/ui/card'
import { SentimentAnalysis } from '@/lib/types'
import { PieChart, Pie, BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts'

interface SentimentChartsProps {
  analysis: SentimentAnalysis
}

export function SentimentCharts({ analysis }: SentimentChartsProps) {
  const pieData = [
    { name: 'Positive', value: analysis.sentiment.positive },
    { name: 'Neutral', value: analysis.sentiment.neutral },
    { name: 'Negative', value: analysis.sentiment.negative },
  ]

  const barData = [
    {
      name: 'Positive',
      count: Math.round((analysis.sentiment.positive / 100) * analysis.reviewCount),
    },
    {
      name: 'Neutral',
      count: Math.round((analysis.sentiment.neutral / 100) * analysis.reviewCount),
    },
    {
      name: 'Negative',
      count: Math.round((analysis.sentiment.negative / 100) * analysis.reviewCount),
    },
  ]

  const lineData = Array.from({ length: 30 }, (_, i) => ({
    day: i + 1,
    sentiment: 50 + Math.sin(i * 0.3) * 20 + Math.random() * 10,
  }))

  const COLORS = ['#65C96E', '#A6A6A6', '#F44B4B']
  const BAR_COLORS = ['#65C96E', '#A6A6A6', '#F44B4B']

  return (
    <div className="grid grid-cols-2 gap-6">
      {/* Pie Chart */}
      <Card className="p-6">
        <h3 className="font-semibold text-foreground mb-4">Sentiment Distribution</h3>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={pieData}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={({ name, value }) => `${name}: ${value}%`}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
            >
              {pieData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip formatter={(value) => `${value}%`} />
          </PieChart>
        </ResponsiveContainer>
      </Card>

      {/* Bar Chart */}
      <Card className="p-6">
        <h3 className="font-semibold text-foreground mb-4">Review Count by Sentiment</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={barData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="count" fill="#8884d8" radius={[8, 8, 0, 0]}>
              {barData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={BAR_COLORS[index % BAR_COLORS.length]} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Line Chart */}
      <Card className="p-6 col-span-2">
        <h3 className="font-semibold text-foreground mb-4">Sentiment Trend (Last 30 Days)</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={lineData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="day" />
            <YAxis domain={[30, 70]} />
            <Tooltip formatter={(value) => value.toFixed(1)} />
            <Line
              type="monotone"
              dataKey="sentiment"
              stroke="#65C96E"
              strokeWidth={2}
              dot={false}
              isAnimationActive={true}
            />
          </LineChart>
        </ResponsiveContainer>
      </Card>
    </div>
  )
}
