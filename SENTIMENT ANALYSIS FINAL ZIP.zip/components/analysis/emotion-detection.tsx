'use client'

import { Card } from '@/components/ui/card'
import { SentimentAnalysis } from '@/lib/types'
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer } from 'recharts'

interface EmotionDetectionProps {
  analysis: SentimentAnalysis
}

export function EmotionDetection({ analysis }: EmotionDetectionProps) {
  const radarData = [
    {
      name: 'Happy',
      value: analysis.emotions.happy,
      fullMark: 100,
    },
    {
      name: 'Angry',
      value: analysis.emotions.angry,
      fullMark: 100,
    },
    {
      name: 'Frustrated',
      value: analysis.emotions.frustrated,
      fullMark: 100,
    },
    {
      name: 'Satisfied',
      value: analysis.emotions.satisfied,
      fullMark: 100,
    },
    {
      name: 'Disappointed',
      value: analysis.emotions.disappointed,
      fullMark: 100,
    },
  ]

  return (
    <Card className="p-6">
      <h3 className="font-semibold text-foreground mb-4">Emotion Detection</h3>
      <ResponsiveContainer width="100%" height={400}>
        <RadarChart data={radarData}>
          <PolarGrid />
          <PolarAngleAxis dataKey="name" />
          <PolarRadiusAxis angle={90} domain={[0, 100]} />
          <Radar
            name="Emotion Level"
            dataKey="value"
            stroke="#6B5BFF"
            fill="#6B5BFF"
            fillOpacity={0.6}
            isAnimationActive={true}
          />
        </RadarChart>
      </ResponsiveContainer>
      <div className="grid grid-cols-5 gap-4 mt-6 pt-4 border-t border-border">
        {radarData.map((emotion) => (
          <div key={emotion.name} className="text-center">
            <p className="text-xs text-muted-foreground mb-1">{emotion.name}</p>
            <p className="text-lg font-bold text-primary">{emotion.value}%</p>
          </div>
        ))}
      </div>
    </Card>
  )
}
