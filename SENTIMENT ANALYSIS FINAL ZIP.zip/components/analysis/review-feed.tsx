'use client'

import { Card } from '@/components/ui/card'
import { SentimentAnalysis, Review } from '@/lib/types'
import { Badge } from '@/components/ui/badge'
import { formatDistanceToNow } from 'date-fns'

interface ReviewFeedProps {
  analysis: SentimentAnalysis
}

function getSentimentColor(sentiment: string) {
  switch (sentiment) {
    case 'positive':
      return 'bg-sentiment-positive/10 text-sentiment-positive border-sentiment-positive'
    case 'negative':
      return 'bg-sentiment-negative/10 text-sentiment-negative border-sentiment-negative'
    default:
      return 'bg-sentiment-neutral/10 text-sentiment-neutral border-sentiment-neutral'
  }
}

export function ReviewFeed({ analysis }: ReviewFeedProps) {
  return (
    <Card className="p-6">
      <h3 className="font-semibold text-foreground mb-4">Review Feed</h3>
      <div className="space-y-4 max-h-96 overflow-y-auto">
        {analysis.reviews.slice(0, 10).map((review) => (
          <div key={review.id} className="p-4 border border-border rounded-lg hover:bg-secondary/30 transition-colors">
            <div className="flex items-start justify-between mb-2">
              <div>
                <p className="font-medium text-foreground">{review.username}</p>
                <p className="text-xs text-muted-foreground">
                  {formatDistanceToNow(review.date, { addSuffix: true })}
                </p>
              </div>
              <Badge
                variant="outline"
                className={`capitalize ${getSentimentColor(review.sentiment)}`}
              >
                {review.sentiment}
              </Badge>
            </div>
            <p className="text-sm text-foreground line-clamp-2">{review.text}</p>
            {review.rating && (
              <div className="flex items-center gap-1 mt-2">
                <span className="text-xs text-muted-foreground">Rating:</span>
                <span className="text-sm font-medium text-primary">{review.rating}/5</span>
                <span className="text-sm">{'⭐'.repeat(review.rating)}</span>
              </div>
            )}
          </div>
        ))}
      </div>
    </Card>
  )
}
