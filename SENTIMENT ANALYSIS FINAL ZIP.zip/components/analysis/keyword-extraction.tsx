'use client'

import { Card } from '@/components/ui/card'
import { SentimentAnalysis } from '@/lib/types'

interface KeywordExtractionProps {
  analysis: SentimentAnalysis
}

export function KeywordExtraction({ analysis }: KeywordExtractionProps) {
  return (
    <div className="grid grid-cols-2 gap-6">
      {/* Positive Keywords */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">Top Positive Keywords</h3>
          <div className="h-3 w-3 rounded-full bg-sentiment-positive"></div>
        </div>
        <div className="space-y-3">
          {analysis.topPositiveKeywords.map((keyword, index) => (
            <div key={keyword} className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-full bg-sentiment-positive/10 flex items-center justify-center text-xs font-bold text-sentiment-positive">
                {index + 1}
              </div>
              <span className="text-foreground capitalize font-medium">{keyword}</span>
              <div className="ml-auto h-2 w-24 bg-secondary rounded-full overflow-hidden">
                <div
                  className="h-full bg-sentiment-positive"
                  style={{ width: `${100 - index * 15}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Negative Keywords */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">Top Negative Keywords</h3>
          <div className="h-3 w-3 rounded-full bg-sentiment-negative"></div>
        </div>
        <div className="space-y-3">
          {analysis.topNegativeKeywords.map((keyword, index) => (
            <div key={keyword} className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-full bg-sentiment-negative/10 flex items-center justify-center text-xs font-bold text-sentiment-negative">
                {index + 1}
              </div>
              <span className="text-foreground capitalize font-medium">{keyword}</span>
              <div className="ml-auto h-2 w-24 bg-secondary rounded-full overflow-hidden">
                <div
                  className="h-full bg-sentiment-negative"
                  style={{ width: `${100 - index * 15}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
