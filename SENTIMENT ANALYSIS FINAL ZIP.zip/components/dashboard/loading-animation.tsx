'use client'

import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'

const steps = [
  'Collecting reviews...',
  'Running sentiment model...',
  'Analyzing emotions...',
  'Generating insights...',
]

export function LoadingAnimation() {
  const [step, setStep] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setStep((prev) => (prev + 1) % steps.length)
    }, 1500)

    return () => clearInterval(interval)
  }, [])

  return (
    <Card className="p-8">
      <div className="flex flex-col items-center justify-center py-12 space-y-6">
        <div className="relative h-16 w-16">
          <div className="absolute inset-0 rounded-full border-4 border-primary/20"></div>
          <div className="absolute inset-0 rounded-full border-4 border-transparent border-t-primary animate-spin"></div>
        </div>

        <div className="text-center space-y-4">
          <h3 className="text-lg font-semibold text-foreground">Analyzing Sentiment</h3>
          <p className="text-sm text-muted-foreground h-6">{steps[step]}</p>
        </div>

        <div className="w-full max-w-xs space-y-2">
          {steps.map((_, index) => (
            <div key={index} className="flex items-center gap-2">
              <div
                className={`h-2 flex-1 rounded-full transition-all ${
                  index <= step ? 'bg-primary' : 'bg-secondary'
                }`}
              ></div>
              {index <= step && <div className="h-2 w-2 rounded-full bg-primary animate-pulse"></div>}
            </div>
          ))}
        </div>
      </div>
    </Card>
  )
}
