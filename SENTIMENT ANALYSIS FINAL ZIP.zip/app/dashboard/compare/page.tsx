'use client'

import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ArrowRight } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useState } from 'react'

export default function ComparePage() {
  const [url1, setUrl1] = useState('')
  const [url2, setUrl2] = useState('')
  const router = useRouter()

  const handleCompare = (e: React.FormEvent) => {
    e.preventDefault()
    if (url1 && url2) {
      router.push(`/dashboard/compare/result?url1=${encodeURIComponent(url1)}&url2=${encodeURIComponent(url2)}`)
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Compare Products</h1>
        <p className="text-muted-foreground">Compare sentiment analysis between two products or competitors</p>
      </div>

      <Card className="p-8">
        <form onSubmit={handleCompare} className="space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="block text-sm font-semibold">Product 1</label>
              <Input
                type="url"
                placeholder="https://www.amazon.com/product/..."
                value={url1}
                onChange={(e) => setUrl1(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-semibold">Product 2</label>
              <Input
                type="url"
                placeholder="https://www.amazon.com/product/..."
                value={url2}
                onChange={(e) => setUrl2(e.target.value)}
              />
            </div>
          </div>

          <Button type="submit" disabled={!url1 || !url2} className="w-full" size="lg">
            Compare
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </form>
      </Card>
    </div>
  )
}
