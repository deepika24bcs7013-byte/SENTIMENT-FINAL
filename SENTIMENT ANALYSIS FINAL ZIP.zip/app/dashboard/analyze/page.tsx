'use client'

import { useSearchParams } from 'next/navigation'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { SentimentOverview } from '@/components/analysis/sentiment-overview'
import { SentimentCharts } from '@/components/analysis/sentiment-charts'
import { EmotionDetection } from '@/components/analysis/emotion-detection'
import { KeywordExtraction } from '@/components/analysis/keyword-extraction'
import { ReviewFeed } from '@/components/analysis/review-feed'
import { FakeReviewDetection } from '@/components/analysis/fake-review-detection'
import { BuyRecommendation } from '@/components/analysis/buy-recommendation'
import { generateMockAnalysis } from '@/lib/mock-data'
import { ArrowLeft, Download } from 'lucide-react'
import Link from 'next/link'

export default function AnalysisResultPage() {
  const searchParams = useSearchParams()
  const url = searchParams.get('url') || ''

  const analysis = generateMockAnalysis(url)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Link href="/dashboard/analyze">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Back
              </Button>
            </Link>
          </div>
          <h1 className="text-3xl font-bold text-foreground">Analysis Results</h1>
          <p className="text-muted-foreground mt-1">
            Analysis of: <code className="bg-secondary px-2 py-1 rounded text-sm">{url}</code>
          </p>
        </div>
        <Button className="gap-2">
          <Download className="h-4 w-4" />
          Export Report
        </Button>
      </div>

      {/* Sentiment Overview */}
      <section>
        <h2 className="text-xl font-semibold text-foreground mb-4">Sentiment Overview</h2>
        <SentimentOverview analysis={analysis} />
      </section>

      {/* Buy Recommendation */}
      <section>
        <BuyRecommendation analysis={analysis} />
      </section>

      {/* Charts */}
      <section>
        <h2 className="text-xl font-semibold text-foreground mb-4">Visualizations</h2>
        <SentimentCharts analysis={analysis} />
      </section>

      {/* Emotion Detection */}
      <section>
        <h2 className="text-xl font-semibold text-foreground mb-4">Emotion Analysis</h2>
        <EmotionDetection analysis={analysis} />
      </section>

      {/* Keywords */}
      <section>
        <h2 className="text-xl font-semibold text-foreground mb-4">Key Insights</h2>
        <KeywordExtraction analysis={analysis} />
      </section>

      {/* Risk & Rating */}
      <section>
        <h2 className="text-xl font-semibold text-foreground mb-4">Quality Metrics</h2>
        <FakeReviewDetection analysis={analysis} />
      </section>

      {/* Reviews */}
      <section>
        <h2 className="text-xl font-semibold text-foreground mb-4">Recent Reviews</h2>
        <ReviewFeed analysis={analysis} />
      </section>

      {/* Footer */}
      <div className="text-center py-6 border-t border-border">
        <p className="text-sm text-muted-foreground">
          Analysis generated at {new Date(analysis.timestamp).toLocaleString()}
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          This analysis is based on mock data for demonstration purposes.
        </p>
      </div>
    </div>
  )
}
