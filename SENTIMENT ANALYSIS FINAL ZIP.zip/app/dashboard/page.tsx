'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { ArrowRight, BarChart3 } from 'lucide-react'
import { toast } from 'sonner'

export default function DashboardPage() {
  const [url, setUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!url.trim()) {
      toast.error('Please enter a URL')
      return
    }

    setLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 500))
    router.push(`/dashboard/analyze?url=${encodeURIComponent(url)}`)
    setLoading(false)
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold text-foreground mb-2">Sentiment Analysis</h1>
        <p className="text-lg text-muted-foreground">
          Analyze product reviews and social media sentiment with AI-powered insights
        </p>
      </div>

      {/* Main Card */}
      <Card className="p-8 border-2">
        <form onSubmit={handleAnalyze} className="space-y-6">
          <div className="space-y-2">
            <label className="block text-sm font-semibold">
              Paste Product or Social Media Link
            </label>
            <p className="text-sm text-muted-foreground">
              Enter a URL from Amazon, Reddit, YouTube, Twitter, or Instagram
            </p>
          </div>

          <div className="flex gap-2">
            <Input
              type="url"
              placeholder="https://www.amazon.com/product/..."
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              disabled={loading}
              className="text-lg py-6"
            />
            <Button
              type="submit"
              disabled={loading || !url.trim()}
              className="px-8"
              size="lg"
            >
              {loading ? 'Analyzing...' : (
                <>
                  Analyze
                  <ArrowRight className="ml-2 h-5 w-5" />
                </>
              )}
            </Button>
          </div>
        </form>
      </Card>

      {/* Features Grid */}
      <div className="grid grid-cols-3 gap-6">
        <Card className="p-6">
          <div className="flex items-start gap-4">
            <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
              <BarChart3 className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">Sentiment Breakdown</h3>
              <p className="text-sm text-muted-foreground">
                See positive, neutral, and negative sentiment percentages
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start gap-4">
            <div className="h-12 w-12 rounded-lg bg-accent/10 flex items-center justify-center">
              <BarChart3 className="h-6 w-6 text-accent" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">Emotion Detection</h3>
              <p className="text-sm text-muted-foreground">
                Identify emotions like happy, angry, frustrated, and more
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start gap-4">
            <div className="h-12 w-12 rounded-lg bg-destructive/10 flex items-center justify-center">
              <BarChart3 className="h-6 w-6 text-destructive" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">Fake Review Detection</h3>
              <p className="text-sm text-muted-foreground">
                Identify suspicious reviews with AI-powered detection
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
