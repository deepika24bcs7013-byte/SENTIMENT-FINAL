'use client'

import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Moon, Trash2 } from 'lucide-react'

export default function SettingsPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Settings</h1>
        <p className="text-muted-foreground">Manage your preferences and account settings</p>
      </div>

      {/* Display Settings */}
      <Card className="p-6">
        <h3 className="font-semibold text-foreground mb-4">Display Settings</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between pb-4 border-b border-border">
            <div className="flex items-center gap-3">
              <Moon className="h-5 w-5 text-muted-foreground" />
              <div>
                <p className="font-medium text-foreground">Dark Mode</p>
                <p className="text-sm text-muted-foreground">Toggle dark theme</p>
              </div>
            </div>
            <Switch />
          </div>
        </div>
      </Card>

      {/* Data Management */}
      <Card className="p-6">
        <h3 className="font-semibold text-foreground mb-4">Data Management</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between pb-4 border-b border-border">
            <div>
              <p className="font-medium text-foreground">Clear History</p>
              <p className="text-sm text-muted-foreground">Delete all analysis history</p>
            </div>
            <Button variant="destructive" size="sm" className="gap-2">
              <Trash2 className="h-4 w-4" />
              Clear
            </Button>
          </div>
        </div>
      </Card>

      {/* About */}
      <Card className="p-6 bg-secondary/30">
        <h3 className="font-semibold text-foreground mb-2">About Sentilytics</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Sentilytics is a powerful sentiment analysis platform that helps you understand customer sentiment across
          various platforms and products.
        </p>
        <p className="text-xs text-muted-foreground">Version 1.0.0</p>
      </Card>
    </div>
  )
}
