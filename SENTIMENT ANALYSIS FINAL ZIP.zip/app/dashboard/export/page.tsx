'use client'

import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { FileText, Download } from 'lucide-react'

export default function ExportPage() {
  const handleExport = (format: 'pdf' | 'csv' | 'json') => {
    console.log(`Exporting as ${format}...`)
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Export Reports</h1>
        <p className="text-muted-foreground">Download your sentiment analysis reports in various formats</p>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {[
          { format: 'PDF', description: 'Professional formatted report', icon: FileText },
          { format: 'CSV', description: 'Spreadsheet compatible data', icon: FileText },
          { format: 'JSON', description: 'Raw data for integration', icon: FileText },
        ].map((item) => (
          <Card key={item.format} className="p-6">
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <item.icon className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">{item.format}</h3>
                <p className="text-xs text-muted-foreground">{item.description}</p>
              </div>
              <Button
                onClick={() => handleExport(item.format.toLowerCase() as any)}
                className="w-full gap-2"
              >
                <Download className="h-4 w-4" />
                Export
              </Button>
            </div>
          </Card>
        ))}
      </div>

      <Card className="p-6 bg-secondary/30 border-primary/20">
        <h3 className="font-semibold text-foreground mb-2">Bulk Export</h3>
        <p className="text-sm text-muted-foreground mb-4">Export all your analyses at once</p>
        <Button variant="outline">Export All Analyses</Button>
      </Card>
    </div>
  )
}
