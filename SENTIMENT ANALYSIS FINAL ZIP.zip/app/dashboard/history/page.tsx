'use client'

import { Card } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Button } from '@/components/ui/button'

export default function HistoryPage() {
  const recentAnalyses = [
    {
      id: 1,
      url: 'https://www.amazon.com/...',
      date: '2024-03-17',
      sentiment: 72,
    },
    {
      id: 2,
      url: 'https://www.reddit.com/...',
      date: '2024-03-16',
      sentiment: 58,
    },
    {
      id: 3,
      url: 'https://www.youtube.com/...',
      date: '2024-03-15',
      sentiment: 65,
    },
  ]

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Analysis History</h1>
        <p className="text-muted-foreground">View all your previous sentiment analyses</p>
      </div>

      <Card className="p-6">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>URL</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Sentiment Score</TableHead>
              <TableHead className="text-right">Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {recentAnalyses.map((analysis) => (
              <TableRow key={analysis.id}>
                <TableCell className="font-mono text-sm">{analysis.url}</TableCell>
                <TableCell>{analysis.date}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-24 bg-secondary rounded-full overflow-hidden">
                      <div
                        className="h-full bg-sentiment-positive"
                        style={{ width: `${analysis.sentiment}%` }}
                      ></div>
                    </div>
                    <span className="font-medium">{analysis.sentiment}%</span>
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">
                    View
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  )
}
