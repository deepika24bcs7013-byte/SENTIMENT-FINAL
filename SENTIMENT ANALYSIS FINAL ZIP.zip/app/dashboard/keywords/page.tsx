'use client'

import { Card } from '@/components/ui/card'

export default function KeywordsPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Keyword Insights</h1>
        <p className="text-muted-foreground">Deep dive into keywords and phrases driving sentiment</p>
      </div>

      <Card className="p-8">
        <div className="text-center py-12">
          <p className="text-muted-foreground mb-4">No analyses yet</p>
          <p className="text-sm text-muted-foreground">Analyze a product to see detailed keyword insights</p>
        </div>
      </Card>
    </div>
  )
}
