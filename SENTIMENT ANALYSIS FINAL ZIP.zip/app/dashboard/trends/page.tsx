'use client'

import { Card } from '@/components/ui/card'

export default function TrendsPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Sentiment Trends</h1>
        <p className="text-muted-foreground">Track sentiment changes over time across your analyzed products</p>
      </div>

      <Card className="p-8">
        <div className="text-center py-12">
          <p className="text-muted-foreground mb-4">Select a product to view sentiment trends</p>
          <p className="text-sm text-muted-foreground">Use the Analyze Link feature to start tracking sentiment over time</p>
        </div>
      </Card>
    </div>
  )
}
