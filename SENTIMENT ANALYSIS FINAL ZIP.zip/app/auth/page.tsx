'use client'

import { useState } from 'react'
import { useAuth } from '@/hooks/use-auth'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { toast } from 'sonner'

export default function AuthPage() {
  const [registrationNumber, setRegistrationNumber] = useState('')
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    if (login(registrationNumber)) {
      toast.success('Login successful!')
    } else {
      toast.error('Invalid registration number. Please try again.')
      setRegistrationNumber('')
    }

    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-lg">
        <div className="p-8">
          <div className="mb-8 text-center">
            <h1 className="text-4xl font-bold text-primary mb-2">Sentilytics</h1>
            <p className="text-muted-foreground">AI-Powered Sentiment Analysis</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <label htmlFor="registration" className="block text-sm font-medium">
                Registration Number
              </label>
              <Input
                id="registration"
                type="text"
                placeholder="Enter your registration number"
                value={registrationNumber}
                onChange={(e) => setRegistrationNumber(e.target.value)}
                disabled={loading}
                autoFocus
                className="font-mono"
              />
              <p className="text-xs text-muted-foreground">
                Demo: Use <code className="bg-muted px-2 py-1 rounded">24BCS7013</code>
              </p>
            </div>

            <Button type="submit" className="w-full" size="lg" disabled={loading || !registrationNumber}>
              {loading ? 'Logging in...' : 'Login'}
            </Button>
          </form>

          <div className="mt-8 pt-6 border-t border-border text-center text-sm text-muted-foreground">
            <p>This is a demo application.</p>
            <p>Enter the registration number to access the dashboard.</p>
          </div>
        </div>
      </Card>
    </div>
  )
}
