export interface Review {
  id: string
  username: string
  text: string
  sentiment: 'positive' | 'neutral' | 'negative'
  date: Date
  rating?: number
}

export interface SentimentAnalysis {
  id: string
  url: string
  platform: 'reddit' | 'amazon' | 'youtube' | 'twitter' | 'instagram' | 'other'
  timestamp: Date
  sentiment: {
    positive: number
    neutral: number
    negative: number
    overallScore: number
  }
  emotions: {
    happy: number
    angry: number
    frustrated: number
    satisfied: number
    disappointed: number
  }
  topPositiveKeywords: string[]
  topNegativeKeywords: string[]
  reviews: Review[]
  fakeReviewPercentage: number
  predictedRating: number
  reviewCount: number
}

export interface AuthState {
  isAuthenticated: boolean
  registrationNumber: string | null
}
