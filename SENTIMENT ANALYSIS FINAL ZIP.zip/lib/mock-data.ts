import { SentimentAnalysis, Review } from './types'

const positiveReviews = [
  'Amazing product! Exceeded my expectations.',
  'Best purchase ever, highly recommended!',
  'Excellent quality and fast shipping.',
  'Love it! Worth every penny.',
  'Perfect! Exactly what I needed.',
  'Outstanding service and product.',
  'Very satisfied with this purchase.',
  'Great value for money!',
  'Fantastic experience overall.',
  'Impressed with the quality!',
]

const neutralReviews = [
  'It is what it is, decent product.',
  'Average quality, nothing special.',
  'Okay product, does the job.',
  'Neither great nor bad.',
  'Meets basic expectations.',
  'Standard product, as described.',
  'Not bad, but not exceptional.',
  'It works fine.',
  'Acceptable quality.',
  'Normal delivery time.',
]

const negativeReviews = [
  'Terrible quality, very disappointed.',
  'Waste of money, do not buy!',
  'Poor customer service and product.',
  'Broke after a few days.',
  'Very frustrated with this purchase.',
  'Not as advertised at all.',
  'Worst experience ever.',
  'Defective product received.',
  'Extremely unsatisfied.',
  'Would give negative stars if possible.',
]

const keywords = {
  positive: [
    'quality',
    'amazing',
    'excellent',
    'fast',
    'worth',
    'perfect',
    'love',
    'great',
    'fantastic',
    'best',
  ],
  negative: [
    'poor',
    'defective',
    'broke',
    'disappointed',
    'terrible',
    'waste',
    'frustrating',
    'cheap',
    'useless',
    'broken',
  ],
}

const usernames = [
  'John_D',
  'Sarah_M',
  'Mike_92',
  'Lisa_K',
  'Alex_T',
  'Emma_W',
  'Chris_H',
  'Sophie_L',
  'David_B',
  'Rachel_P',
]

function getRandomItem<T>(array: T[]): T {
  return array[Math.floor(Math.random() * array.length)]
}

function generateReviews(count: number): Review[] {
  const reviews: Review[] = []
  const now = new Date()

  for (let i = 0; i < count; i++) {
    const sentiment = Math.random() > 0.5 ? (Math.random() > 0.6 ? 'positive' : 'negative') : 'neutral'
    let text = ''

    if (sentiment === 'positive') {
      text = getRandomItem(positiveReviews)
    } else if (sentiment === 'negative') {
      text = getRandomItem(negativeReviews)
    } else {
      text = getRandomItem(neutralReviews)
    }

    reviews.push({
      id: `review-${i}`,
      username: getRandomItem(usernames),
      text,
      sentiment,
      date: new Date(now.getTime() - Math.random() * 30 * 24 * 60 * 60 * 1000),
      rating: Math.floor(Math.random() * 5) + 1,
    })
  }

  return reviews
}

export function generateMockAnalysis(url: string): SentimentAnalysis {
  const reviews = generateReviews(50)

  const positiveCount = reviews.filter((r) => r.sentiment === 'positive').length
  const neutralCount = reviews.filter((r) => r.sentiment === 'neutral').length
  const negativeCount = reviews.filter((r) => r.sentiment === 'negative').length

  const positivePercent = Math.round((positiveCount / reviews.length) * 100)
  const neutralPercent = Math.round((neutralCount / reviews.length) * 100)
  const negativePercent = Math.round((negativeCount / reviews.length) * 100)

  const overallScore =
    (positiveCount * 1 + neutralCount * 0.5 + negativeCount * 0) / reviews.length

  return {
    id: `analysis-${Date.now()}`,
    url,
    platform: ['amazon', 'reddit', 'youtube', 'twitter'][Math.floor(Math.random() * 4)] as any,
    timestamp: new Date(),
    sentiment: {
      positive: positivePercent,
      neutral: neutralPercent,
      negative: negativePercent,
      overallScore: Math.round(overallScore * 100) / 100,
    },
    emotions: {
      happy: Math.floor(Math.random() * 40) + 20,
      angry: Math.floor(Math.random() * 25) + 5,
      frustrated: Math.floor(Math.random() * 30) + 10,
      satisfied: Math.floor(Math.random() * 35) + 15,
      disappointed: Math.floor(Math.random() * 20) + 5,
    },
    topPositiveKeywords: keywords.positive.slice(0, 5),
    topNegativeKeywords: keywords.negative.slice(0, 5),
    reviews,
    fakeReviewPercentage: Math.floor(Math.random() * 15) + 2,
    predictedRating: Math.round((positiveCount / reviews.length) * 5 * 10) / 10,
    reviewCount: reviews.length,
  }
}
